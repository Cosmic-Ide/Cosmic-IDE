object BuildAndroidConfig {
    const val APPLICATION_ID = "org.cosmic.ide"

    const val COMPILE_SDK_VERSION = 33
    const val MIN_SDK_VERSION = 26
    const val TARGET_SDK_VERSION = 33

    const val VERSION_CODE = 20
    const val VERSION_NAME = "2.0.0"

    const val SUPPORT_LIBRARY_VECTOR_DRAWABLES = true
}