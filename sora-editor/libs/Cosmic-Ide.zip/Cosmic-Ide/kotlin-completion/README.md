# kotlin-completion

This module was copied from [CodeAssist](https://github.com/tyron12233/CodeAssist/tree/main/kotlin-completion)
to provide Kotlin Code Completion in Cosmic IDE. All credits go to the original developers.

We did some changes to the module for our use case and most as improvements.