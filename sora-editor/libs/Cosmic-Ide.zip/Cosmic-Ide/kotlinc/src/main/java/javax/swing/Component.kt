package javax.swing

open class Component
