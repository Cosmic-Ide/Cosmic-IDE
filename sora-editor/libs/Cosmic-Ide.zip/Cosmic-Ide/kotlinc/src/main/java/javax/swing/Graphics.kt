package javax.swing

open class Graphics
