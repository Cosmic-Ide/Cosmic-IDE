package javax.swing

open class JComponent
