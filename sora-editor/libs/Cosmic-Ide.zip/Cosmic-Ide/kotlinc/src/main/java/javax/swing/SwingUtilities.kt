package javax.swing

object SwingUtilities {
    @JvmStatic
    fun isEventDispatchThread() = true
}
