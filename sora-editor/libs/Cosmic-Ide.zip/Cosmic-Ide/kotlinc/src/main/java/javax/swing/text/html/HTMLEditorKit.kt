package javax.swing.text.html

open class HTMLEditorKit {
    open fun getContentType() = "text/html"

    open class ParserCallback
}
